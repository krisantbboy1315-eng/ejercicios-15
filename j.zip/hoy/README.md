# Guía de ejercicios de herencia - Java

Cada carpeta es un ejercicio Java independiente. Para ejecutarlo desde su carpeta, use:

```powershell
javac -d bin src\App.java
java -cp bin App
```

Cada solución incluye un `README.md` con las decisiones de diseño exigidas por la guía.
